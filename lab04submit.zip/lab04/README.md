Carina Liu
ITWS1100 - INTRO TO ITWS

LAB 4 - XML & MICROFORMATS
9/30/24

Personal Website Link: 
http://127.0.0.1:3000/lab03/index.html

For this lab, I learned how to create an RSS and Atom sheet using XML. For the RSS sheet, the articles that I provided were all
articles about the newest technologies of 2024. I find this topic really interesting, and I feel like it is a really relevant topic
for this class. In my Atom file, I linked the 2024-2025 RPI Academic Calendar for October. Doing this lab, I referenced the RSS and Atom
example file a lot, and I feel like I learned a lot about how xml files work. In the processing of creating my RSS, I also learned 
how to look through an HTML page source file for information such as publishing date. I found this lab really interesting overall. 

Something that I struggled on for this assignment, was trying to find certain information from the page source. For example, I wasn't able
to find the managingEditor for the Atom file, and it was hard to the find the publish date for the events in the Academic Calendar.
